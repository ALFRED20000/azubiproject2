<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Guestbook Data</title>
  <style>
    table {
      width: 100%;
      border-collapse: collapse;
    }
    table, th, td {
      border: 1px solid black;
    }
    th, td {
      padding: 15px;
      text-align: left;
    }
  </style>
</head>
<body>
  <?php
      require 'vendor/autoload.php'; 
      use Aws\DynamoDb\DynamoDbClient;
      use Aws\Exception\AwsException;

      $client = new DynamoDbClient([
        'region' => 'us-east-1',
        'version' =>'latest',
        'credentials' => [
          'key' => 'AKIA4MTWIUC4NK4XX5OH',
          'secret' => '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',
        ],
        ]);
        $tableName = 'guestbook';
        $item = [
          'TableName' => 'tableName',
          'Key' => [
              'id' => [
                  'S' => 'email'
              ]
          ]
      ];
      
      try {
          //$result = $dynamoDb->getItem();
          if (isset($result['Item'])) {
              echo "Item retrieved successfully.\n";
              print_r($result['Item']);
          } else {
              echo "Item not found.\n";
          }
      } catch (AwsException $e) {
          echo "Unable to retrieve item:\n";
          echo $e->getMessage() . "\n";
      }

        ?>
  <h1>Guestbook Data</h1>
  <table>
    <thead>
      <tr>
        <th>Email</th>
        <th>First Name</th>
        <th>Surname</th>
        <th>Age</th>
        <th>Country</th>
        <th>Contacts</th>
      </tr>
    </thead>
    <tbody id="data-table">
    </tbody>
  </table>
  
  <script>
    async function fetchData() {
      try {
        const response = await fetch('/data');
        const data = await response.json();
        const tableBody = document.getElementById('data-table');
        data.forEach(item => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${item.Email}</td>
            <td>${item.FirstName}</td>
            <td>${item.Surname}</td>
            <td>${item.Age}</td>
            <td>${item.Country}</td>
            <td>${item.Contacts}</td>
          `;
          tableBody.appendChild(row);
        });
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    }

    window.onload = fetchData;
  </script>
</body>
</html>
