<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "alfred_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = '';
$user_password = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = isset($_POST['name']) ? $_POST['name'] : null;
    $user_password = isset($_POST['password']) ? $_POST['password'] : null;

    if (!$name || !$user_password) {
        echo "All fields are required";
    } else {
        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO users (name, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $user_password);

        // Execute the statement
        if ($stmt->execute()) {
            header('Location: success.php');
        } else {
            header('Location: error.html');
        }
        exit();
    }
}
?>

