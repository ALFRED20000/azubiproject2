-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2024 at 08:47 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alfred_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `password`) VALUES
(1, 'ffdfd', 'sdvsdfv'),
(2, 'ffdfd', 'sdvsdfv'),
(3, 'ffdfd', 'sdvsdfv'),
(4, 'alfred', '234567'),
(5, 'alfred', '123456'),
(6, 'ffdfd', 'fv'),
(7, 'ffdfd', '23456ui'),
(8, 'ffdfd', '12345'),
(9, 'ffdfd', '12345'),
(10, 'ffdfd', '23'),
(11, 'ffdfd12', '1234ty'),
(12, 'ffdfd', '12345'),
(13, 'ffdfd', '123456'),
(14, 'ffdfd', '1234'),
(15, 'ffdfd', '123456'),
(16, 'ffdfd12', 'ffjgjjghjcx'),
(17, 'Baffour', 'Chonchon1'),
(18, 'Baffour', '123456'),
(19, 'Baffour', '1234'),
(20, 'Baffour', 'jfjuhcjhgjcjg'),
(21, 'Baffour', 'jfjuhcjhgjcjg'),
(22, 'bvbb', 'dsdsfvzdxzc'),
(23, 'bvbb', 'vgvhhgvn'),
(24, 'alfred', '123456'),
(25, 'ffdfd', '123456'),
(26, 'ffdfd', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
